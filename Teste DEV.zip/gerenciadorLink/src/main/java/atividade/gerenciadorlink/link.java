/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade.gerenciadorlink;

/**
 *
 * @author COPEL
 */
public class link {
    static int id;

    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        link.id = id;
    }

    

  public void gerarId(){
      id=id+1;
  }
    
    
}
